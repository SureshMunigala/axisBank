import React, { useEffect } from "react";
import { BrowserRouter as Router, Route, Routes, useNavigate } from "react-router-dom";

import Protected from './Protected';
import Login from "./containers/Login";
import Dashboard from "./containers/Dashboard";
import UserDetails from "./containers/UserDetails";
import AccountDetails from "./containers/AccountDetails";
import Onboarding from "./containers/Onboarding";
import SystemDetails from "./containers/SystemDetails";
import BatchProcess from "./containers/BatchProcess";
import Reports from "./containers/Reports";
import Users from "./containers/Users";

const Routers = () => {
  const navigate = useNavigate();
  const isLoggedIn = localStorage.getItem('userData');
  useEffect(() => {
    isLoggedIn == null && navigate('/');
  }, [])

  return (
    <>
      {/* <Router> */}
      <Routes>
        <Route exact path="/" element={<Protected isLoggedIn={isLoggedIn}><Login /></Protected>} />
        <Route exact path="/home" element={<Dashboard />} />
        <Route exact path="/user-details" element={<UserDetails />} />
        <Route exact path="/account-details" element={<AccountDetails />} />
        <Route exact path="/onboarding" element={<Onboarding />} />
        <Route exact path="/system-details" element={<SystemDetails />} />
        <Route exact path="/batch-process" element={<BatchProcess />} />
        <Route exact path="/reports" element={<Reports />} />
        <Route exact path="/users" element={<Users />} />
      </Routes>
      {/* </Router> */}
    </>
  );
};

export default Routers;
