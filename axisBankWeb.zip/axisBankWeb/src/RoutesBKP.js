import React from "react";
import { BrowserRouter as Route, Routes } from "react-router-dom";

import Login from "./containers/Login";
import Dashboard from "./containers/Dashboard";
// import UserDetails from "./containers/UserDetails";
// import AccountDetails from "./containers/AccountDetails";
// import Onboarding from "./containers/Onboarding";
// import SystemDetails from "./containers/SystemDetails";
// import BatchProcess from "./containers/BatchProcess";
// import Reports from "./containers/Reports";
// import Users from "./containers/Users";

const Routers = () => {
  // const loggedIn = localStorage.getItem('userData');
  // console.log('===loggedIn=', loggedIn);
    
  return (
    <>
      {/* <Router> */}
        <Routes>
          {/* <Route exact={true} path="/" element={<Login />} />
          <Route exact={true} path="/home" element={<Dashboard/>} /> */}
          {/* <Route exact={true} path="/" element={!loggedIn ? <Dashboard/> : <Login />} />
          <Route exact={true} path="/home" element={loggedIn ? <Dashboard/> : <Login/>} /> */}
          {/* <Route exact={true} path="/user-details" element={<UserDetails/>} />
          <Route exact={true} path="/account-details" element={<AccountDetails/>} />
          <Route exact={true} path="/onboarding" element={<Onboarding/>} />
          <Route exact={true} path="/system-details" element={<SystemDetails/>} />
          <Route exact={true} path="/batch-process" element={<BatchProcess/>} />
          <Route exact={true} path="/reports" element={<Reports/>} />
          <Route exact={true} path="/users" element={<Users/>} /> */}
        </Routes>
      {/* </Router> */}
    </>
  );
};

export default Routers;
