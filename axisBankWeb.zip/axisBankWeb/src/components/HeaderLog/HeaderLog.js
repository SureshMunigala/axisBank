// HeaderLog
import { Row, Col } from 'antd';
import { useNavigate } from 'react-router-dom';
import moment from 'moment';
// import logoImg from '../../assets/images/logo.png';

const HeaderLog = () => {
  const navigate = useNavigate();
  const authObj = JSON.parse(localStorage.getItem('userData'));
  const lastDate = moment(authObj?.lastLogin).format('L');
  const lastTime = moment(authObj?.lastLogin).format('LTS');

  const logout = () => {
    localStorage.removeItem('userData');
    navigate('/')
  }
  // console.log(moment(authObj.lastLogin).format('DD MM YYYY, h:mm:ss'));
  // console.log(moment(authObj.lastLogin).format('LTS'));
  // console.log(moment(authObj.lastLogin).format('L'));
  return (
    <Row className='hederLog'>
      {/* <img src={logoImg} alt='logo' /> */}
      <Col span={6} offset={6} className='headerText'>
        {authObj?.name && <span className='hederTitle'>LMS Panel</span>}
      </Col>
      <Col span={4} offset={8} className='headerText'>
        {authObj?.name && 
          <span className='userName'>{authObj.name} | <span className='logout' onClick={logout}>Logout</span>
          <br/> {lastDate} {lastTime}</span>
        }
        {/* <p>{authObj.lastLogin}</p> */}
      </Col>
      {/* <Col span={19}>
        <div className='headerTop'></div>
      </Col> */}
    </Row>
  );
}
export default HeaderLog;
