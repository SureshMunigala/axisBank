import React, { useState } from 'react';
import { connect } from 'react-redux';
import { Radio, Layout, Menu } from 'antd';
import { useNavigate } from 'react-router-dom';

import HeaderLog from './HeaderLog/HeaderLog';

const { Sider } = Layout;

const SideNav = props => {
  const navigate = useNavigate();
  const [value, setValue] = useState(props.path);
  
  const onChange = (e) => {
    setValue(e.key);
    navigate('/' + e.key);
  };

  return (
    <>
      <HeaderLog props={props} />
        <Sider className='sider'>
          <Menu
            theme="light"
            mode="inline"
            defaultSelectedKeys={[value]}
            onClick={onChange}
            className='sideNav'
            items={[
              {
                key: 'user-details',
                icon: <Radio checked={value === 'user-details'} />,
                label: 'User Details',
                className:'navbg'
              },
              {
                key: 'account-details',
                icon: <Radio checked={value === 'account-details'} />,
                label: 'Account Details',
                className:'navbg'
              },
              {
                key: 'onboarding',
                icon: <Radio checked={value === 'onboarding'} />,
                label: 'Onboarding',
                className:'navbg'
              },
              {
                key: 'system-details',
                icon: <Radio checked={value === 'system-details'} />,
                label: 'System Details',
                className:'navbg'
              },
              {
                key: 'batch-process',
                icon: <Radio className='btnRadio' checked={value === 'batch-process'} />,
                label: 'Batch Process',
                className:'navbg'
              },
              {
                key: 'reports',
                icon: <Radio checked={value === 'reports'} />,
                label: 'Reports',
                className:'navbg'
              },
              {
                key: 'users',
                icon: <Radio checked={value === 'users'} />,
                label: 'Users',
                className:'navbg'
              },
            ]}
          />
        </Sider>
    </>
  );
};

const mapStateToProps = ({ login }) => {
  const { loading, error, currentUser } = login;
  return { loading, error, currentUser };
};

export default connect(mapStateToProps, {})(SideNav);