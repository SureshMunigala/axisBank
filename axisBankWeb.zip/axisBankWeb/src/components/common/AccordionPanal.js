import { UpOutlined, DownOutlined } from '@ant-design/icons';
import { Collapse } from 'antd';

const { Panel } = Collapse;

const AccordionPanal = props => {

  const onChange = (key) => {
    console.log(key);
  };
  return (
    <>
      <Collapse
        accordion
        defaultActiveKey={['1']}
        onChange={onChange}
        expandIconPosition={props.expandIconPosition}
        expandIcon={props.expandIcon}
        collapsible={props.collapsible}
        className='accordionPanal'
      >
        {props.panels?.map((x, i) => {
          return (
            <Panel header={x.header} key={i + 1}>
              <div>{x.component}</div>
            </Panel>
          )
        })}
      </Collapse>
    </>
  );
};
export default AccordionPanal;