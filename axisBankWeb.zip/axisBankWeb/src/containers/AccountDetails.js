import React from 'react';
import SideNav from '../components/SideNav';
import { Col, Row } from 'antd';

function AccountDetails() {
  return (
    <>
      <SideNav path='account-details' />
      <Row>
        <Col span={6} offset={6} className='asideRight'>
          <p><b>Account Detailss</b> tab selected </p>
        </Col>
      </Row>
    </>
  );
}

export default AccountDetails;
