import React from 'react';
import { Col, Row } from 'antd';
import { UpOutlined, DownOutlined } from '@ant-design/icons';

import SideNav from '../components/SideNav';
import AccordionPanal from '../components/common/AccordionPanal';

function BatchProcess() {
  const panels = [
    { header: "NACH", component: <></> },
    { header: "Account Adjustment", component: <></> }
  ];
  const expandIcon = () => (<UpOutlined />);
  const collapsible = (e) => (<DownOutlined />);

  return (
    <>
      <SideNav path='batch-process' />
      <Row>
        <Col span={6} offset={6} className='asideRight'>
          <AccordionPanal panels={panels} expandIcon={expandIcon} collapsible={collapsible} expandIconPosition='end' />
        </Col>
      </Row>
    </>
  );
}

export default BatchProcess;
