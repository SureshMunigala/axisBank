import { Col, Row } from 'antd';

import SideNav from '../components/SideNav';

const Dashboard = props => {
  return (
    <>
      <SideNav path='' />
      
      <Row>
        <Col span={6} offset={6} className='asideRight'>
          <p>Please select tab to continue</p>
        </Col>
      </Row>
    </>
  );
};
export default Dashboard