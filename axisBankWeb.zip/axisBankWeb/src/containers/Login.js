
import { useEffect, useState } from 'react';
import { Button, Card, Col, Row, Space, Form, Input } from 'antd';
import { useNavigate } from 'react-router-dom';
import { connect, useDispatch } from "react-redux";
import HeaderLog from '../components/HeaderLog/HeaderLog';

import { loginUserAction } from '../redux/login/actions';

function Login(props) {
  const navigate = useNavigate();
  const dispatch = useDispatch();
  const [error, setError] = useState('')

  useEffect(() => {
    props.currentUser?.name && navigate('home');
    props.error && setError(props.error.message);
  }, [props, navigate]);

  const onFinish = (values) => {
    dispatch(loginUserAction(values));
  };
  const onFinishFailed = (errorInfo) => {
    console.log('Failed:', errorInfo);
  };

  return (
    <>
      <HeaderLog />
      <div className='login'>
        <Row>
          <Col span={8} className='card'>
            <Space direction="vertical" size={16}>
              <Card
                title=""
                bordered={true}
                headStyle={{
                  padding: '0.5rem 1rem',
                  marginBottom: 0,
                  background: 'rgba(0,0,0,.03)',
                  borderBottom: '1px solid rgba(0,0,0,.125)',
                }}
                bodyStyle={{ border: '1px solid rgba(0,0,0,.125)' }}
                style={{
                  marginTop: 50,
                  width: 450,
                }}
              >

                <Form
                  name="basic"
                  labelCol={{
                    span: 8,
                  }}
                  wrapperCol={{
                    span: 24,
                  }}
                  layout='vertical'

                  style={{
                    maxWidth: 600,
                  }}
                  initialValues={{
                    remember: true,
                  }}
                  onFinish={onFinish}
                  onFinishFailed={onFinishFailed}
                  autoComplete="off"
                >

                  <h1 className='titleLogin'>Account Sign In</h1>
                  <p className='errorMsg'>&nbsp; {error}</p>
                  <Form.Item
                    label="Username"
                    name="email"
                    style={{
                      // paddingLeft: '120px'
                    }}
                    rules={[
                      {
                        required: true,
                        message: 'Please input your username!',
                      },
                    ]}
                  >
                    <Input />
                  </Form.Item>

                  <Form.Item
                    label="Password"
                    name="password"
                    style={{
                      // paddingLeft: '120px'
                    }}
                    rules={[
                      {
                        required: true,
                        message: 'Please input your password!',
                      },
                    ]}
                  >
                    <Input.Password />
                  </Form.Item>

                  <Form.Item className='buttonSn'>
                    <Button type="primary" block htmlType="submit">Sign In</Button>
                  </Form.Item>
                </Form>
              </Card>
            </Space>
          </Col>
        </Row>
      </div>
    </>
  );
}
const mapStateToProps = ({ login }) => {
  const { loading, error, currentUser } = login;
  return { loading, error, currentUser };
};

export default connect(mapStateToProps, {})(Login);
