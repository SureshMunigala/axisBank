import React from 'react';
import SideNav from '../components/SideNav';
import { Col, Row } from 'antd';

function Reports() {
  return (
    <>
      <SideNav path='reports' />
      <Row>
        <Col span={6} offset={6} className='asideRight'>
          <p><b>Reports</b> tab selected </p>
        </Col>
      </Row>
    </>
  );
}

export default Reports;
