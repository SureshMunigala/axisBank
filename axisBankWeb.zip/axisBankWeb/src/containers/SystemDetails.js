import React from 'react';
import SideNav from '../components/SideNav';
import { Col, Row } from 'antd';

function SystemDetails() {
  return (
    <>
      <SideNav path='system-details' />
      <Row>
        <Col span={6} offset={6} className='asideRight'>
          <p><b>System Details</b> tab selected </p>
        </Col>
      </Row>
    </>
  );
}

export default SystemDetails;
