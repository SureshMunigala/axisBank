import React from 'react';
import SideNav from '../components/SideNav';
import { Col, Row } from 'antd';

function UserDetails() {
  return (
    <>
      <SideNav path='user-details' />
      <Row>
        <Col span={6} offset={6} className='asideRight'>
          <p><b>User Details</b> tab selected </p>
        </Col>
      </Row>
    </>
  );
}

export default UserDetails;
