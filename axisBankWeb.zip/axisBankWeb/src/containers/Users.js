import React, { useEffect } from 'react';
import { Col, Row } from 'antd';
import { UpOutlined, DownOutlined } from '@ant-design/icons';
import { useDispatch } from "react-redux";

import SideNav from '../components/SideNav';
import AccordionPanal from '../components/common/AccordionPanal';
import RoleManagement from '../containers/users/RoleManagement';
import { usersListAction } from '../redux/users/actions';
import UserManager from './users/UserManager';

function Users() {
  const dispatch = useDispatch();

  const panels = [
    {
      header: "Role Management",
      component: <RoleManagement />
    },
    {
      header: "User Manager",
      component: <UserManager />
    }
  ];
  const expandIcon = () => (<UpOutlined />);
  const collapsible = (e) => (<DownOutlined />);

  useEffect(() => {
    const authObj = JSON.parse(localStorage.getItem('userData'));
    dispatch(usersListAction(authObj.jwtToken));
  }, []);

  return (
    <>
      <SideNav path='users' />
      <Row className='asideMain'>
        <Col span={20} offset={4} className='asideRight'>
          <AccordionPanal panels={panels} expandIcon={expandIcon} collapsible={collapsible} expandIconPosition='end' />
        </Col>
      </Row>
    </>
  );
}
export default Users;
