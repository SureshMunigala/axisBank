//  RoleManagement
import React, { useState} from 'react';
import { Col, Row, Input, Button, Table, Space } from 'antd';
import { CloseCircleOutlined } from '@ant-design/icons';
import { connect } from "react-redux";
import moment from 'moment';

const { Search } = Input;

function RoleManagement(props) {

  const [txtSearch, setTxtSearch] = useState('');
  const isDisabled = true;
  const columns = [
    {
      title: 'Role',
      dataIndex: 'roleName',
      key: 'roleName',
      // render: (text) => <a>{text}</a>,
      // className: 'antTableThead'
    },
    {
      title: 'Created',
      dataIndex: 'createdDate',
      key: 'createdDate',
      render: (item) => (moment(item.createdDate).format('L') + moment(item.createdDate).format('LTS'))
    },
    {
      title: 'Last Modified',
      dataIndex: 'lastModifiedDate',
      key: 'lastModifiedDate',
      render: (item) => (moment(item.lastModifiedDate).format('L') + moment(item.lastModifiedDate).format('LTS'))
    },
    {
      title: 'Action',
      key: 'action',
      render: () => (
        <Space size="middle">
          <Button type="link" className='meroon' size='large'>View</Button>
          <Button type="link" className='meroon' size='large'>| Edit</Button>
          <Button type="link" className='meroon' size='large'>| Delete</Button>
        </Space>
      ),
    },
  ];
  const data = props.usersList;
  const onSearch = (value) => setTxtSearch(value);
  const clear = (txtSearch && <CloseCircleOutlined />);

  return (
    <>
      <Row>
        <Col span={20}>
          <Search
            placeholder="Role or Permission"
            allowClear
            enterButton="Search"
            size="large"
            onSearch={onSearch}
            // disabled={isDisabled}
            className='searchBar'
            suffix={clear}
            style={{
              // background: '#961c4e',
              // &{'.ant-input-search-button{background: #961c4e}'}
            }}
          />
        </Col>
        <Col span={4}>
          <Button size='large' className='btnCreate'>Create Role</Button>
        </Col>
        <Table
          className='tblRole'
          size='large'
          columns={columns}
          dataSource={data}
          pagination={false}
          rowClassName='antTableRow'
          headerClassName='antTableThead'
          scroll={{
            y: 315,
          }}
        />
      </Row>
    </>
  );
}


const mapStateToProps = ({ users }) => {
  const { loading, error, usersList } = users;
  return { loading, error, usersList };
};

export default connect(mapStateToProps, {})(RoleManagement);