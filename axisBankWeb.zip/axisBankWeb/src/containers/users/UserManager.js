//  UserManager
import { FileWordOutlined } from '@ant-design/icons';

function UserManager() {
  return (
    <>
      <p className='meroon'><span><FileWordOutlined /></span> Download active users with roles</p>
      <p className='meroon'><span><FileWordOutlined /></span> Download active users with roles & permission mapping</p>
    </>
  );
}

export default UserManager;