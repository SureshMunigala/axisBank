import axios from 'axios';

import {
    LOGIN_USER,
    LOGIN_USER_SUCCESS,
    LOGIN_USER_ERROR,
} from '../../redux/actions.js';
// import { URL, KEY } from '../../constants/defaultValues';
// import { getNormalHeaders } from '../../helpers/Utils';

export const loginUserActionError = (message) => async (dispatch) => {
    dispatch({
        type: LOGIN_USER_ERROR,
        payload: { message }
    });
};

export const loginUserActionSuccess = (user) => async (dispatch) => {
    dispatch({
        type: LOGIN_USER_SUCCESS,
        payload: user
    });
};

export const loginUserAction = (data) => async (dispatch) => {
    try {
        const loginData = {
            ...data,
        };
        dispatch({ type: LOGIN_USER });
        // const axiosConfig = getNormalHeaders(KEY.User_API_Key);
        const result = await axios
            .post(`${'http://localhost:8085/authenticate'}`, loginData)
            .then((user) => user)
            .catch((err) => {
                return err.response;
            });
        if (result && result.status === 200) {
            dispatch(loginUserActionSuccess(result.data));
            localStorage.setItem('userData', JSON.stringify(result.data));
        } else {
            dispatch(loginUserActionError(result.data));
        }
    } catch (error) {
        dispatch(loginUserActionError({}));
    }
};
