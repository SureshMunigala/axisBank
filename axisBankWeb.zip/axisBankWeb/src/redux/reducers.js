import { combineReducers } from 'redux';
import login from './login/reducer';
import users from './users/reducer'

const reducers = combineReducers({
    login,
    users
});

export default reducers;
