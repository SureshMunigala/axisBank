import axios from 'axios';

import {
  USERS_LIST,
  USERS_LIST_SUCCESS,
  USERS_LIST_ERROR,
} from '../../redux/actions.js';

export const usersListActionError = (message) => async (dispatch) => {
  dispatch({
    type: USERS_LIST_ERROR,
    payload: { message }
  });
};

export const usersListActionSuccess = (user) => async (dispatch) => {
  dispatch({
    type: USERS_LIST_SUCCESS,
    payload: user
  });
};

export const usersListAction = (token) => async (dispatch) => {
  try {
    dispatch({ type: USERS_LIST });

    let config = {
      method: 'get',
      maxBodyLength: Infinity,
      url: 'http://localhost:8085/v1/rolemanagement/roles',
      headers: {
        'Authorization': `Bearer` + { token }
      }
    };

    const result = await axios.request(config)
      .then((user) => user)
      .catch((err) => {
        return err.response;
      });

    if (result && result.status === 200) {
      dispatch(usersListActionSuccess(result.data));
    } else {
      dispatch(usersListActionError(result.data));
    }
  } catch (error) {
    dispatch(usersListActionError({}));
  }
};
