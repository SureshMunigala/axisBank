// Foulders Reducers //
import { USERS_LIST, USERS_LIST_SUCCESS, USERS_LIST_ERROR } from '../../redux/actions.js';

const INIT_STATE = {
  usersList: []
};

export default (state = INIT_STATE, action) => {
  const newState = { ...state };
  switch (action.type) {
  case USERS_LIST:
    return { ...state, loading: true, error: '' }; 
  case USERS_LIST_SUCCESS:
    return {
      ...state,
      loading: false,
      usersList: action.payload.content, 
      error: ''
    };
  case USERS_LIST_ERROR:
    return {
      ...state,
      loading: false,
      usersList: null,
      error: action.payload.message,
    };
  default:
    return newState;
  }
};
